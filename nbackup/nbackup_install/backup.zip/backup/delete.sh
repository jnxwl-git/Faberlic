sudo rm -rf /data/backup

sudo rm -rf /usr/lib/systemd/system/backup.service

sudo rm -rf /usr/lib/systemd/system/backup.timer
