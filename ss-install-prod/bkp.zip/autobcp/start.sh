cd /data/autobcp/
pwd
sudo python3 ./main.py KOD