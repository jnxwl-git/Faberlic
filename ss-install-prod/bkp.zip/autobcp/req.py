import requests
import json

def sendGetRequest(url,timeout=60):
    r = requests.get(url, timeout=int(timeout))
    return json.dumps(r.json(), ensure_ascii=False)

