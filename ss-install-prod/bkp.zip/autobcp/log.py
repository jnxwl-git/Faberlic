import logging
import datetime
import os

current_time = datetime.datetime.now()
formated_time=current_time.strftime('%d_%m_%y')
logger = logging.getLogger('')
logger.setLevel(logging.DEBUG)
fileHandler = logging.FileHandler('{}/log/log_{}.log'.format(os.getcwd(),formated_time))
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s ')
fileHandler.setFormatter(formatter)
logger.addHandler(fileHandler)

#logging.basicConfig(filename=f'log_{formated_time}.log', level=logging.DEBUG)
