from log import logging
from mail_sender import Send_mail, mailMessage
from fb import startBackupRestore, executeSQL, shutdownBase, bringBaseOnline
from file_transfer import copyDBintoAncidentFolder, renameBaseForClear, makeDir, copyDBintoClearFolder, \
    renameClearBaseIntoWork, copyDBintoWorkFolder, CreateAndClearOldArchive, clearFolder
import configparser, sys, datetime, os

# в случае исключения rename -> DB_PATH/CLEAR_DB_NAME -> DB_PATH/DB_FILE  -> bring online -> Отправляем исключение на почту

# шатдауним базу  - done
# переносим базу в папку для инциндентов - done
# renameBase DB_PATH/DB_FILE -> DB_PATH/CLEAR_DB_NAME - done
# copyBase in bcp folder  DB_PATH/CLEAR_DB_NAME -> bcp_path/CLEAR_DB_NAME - done
# online bcp_path/CLEAR_DB_NAME - done
# clear renamed Base скрипты на bcp_path/CLEAR_DB_NAME - !!!!!!!!!!!!!!!!
# backup bcp_path/CLEAR_DB_NAME - done
# restore bcp_path/CLEAR_DB_NAME_RESTORE - done
# shutdown bcp_path/CLEAR_DB_NAME - done
# copy in work db_folder bcp_path/CLEAR_DB_NAME -> DB_PATH/CLEAR_DB_NAME - ?
# rename into work DB_PATH/CLEAR_DB_NAME -> DB_PATH/DB_FILE - ?
# online DB_PATH/DB_FILE


logger = logging.getLogger('Main')
logger.info('Program start')
mail_msg = mailMessage('Info:')
config = configparser.ConfigParser()
if len(sys.argv) > 1:
    logger.info('Read file: {}.ini'.format(sys.argv[1]))
    config.read('{}.ini'.format(sys.argv[1]))
    time_start = datetime.datetime.now()
    try:
        ancident_rule = config['RULES']['move_to_ancident']
        clear_rule = config['RULES']['clear_db']
        DB_ALIAS = config['BASE']['DATABASE_ALIAS']
        CLEAR_BASE_NAME = config['BASE']['CLEAR_BASE_NAME']
        bcp_path = config['BASE']['bcp_path']
        SERVER_NAME = config['MAIL']['SERVER_NAME']

        shutdownBase(DB_ALIAS)
        makeDir(config)
        if (ancident_rule == 'True'):
            copyDBintoAncidentFolder(mail_msg, config)
        renameBaseForClear(config)
        copyDBintoClearFolder(config)
        bringBaseOnline('{}{}'.format(bcp_path, CLEAR_BASE_NAME))
        if (clear_rule == 'True'):
            startBackupRestore(mail_msg, config, True)
        else:
            startBackupRestore(mail_msg, config, False)
            # Send_mail('success bcp',mail_msg.getMsg())
        copyDBintoWorkFolder(config)
        renameClearBaseIntoWork(config)
    except Exception as e:
        logger.warning('program failed: ' + str(e))
        mail_msg.addMsg('program failed: ' + str(e))
        renameClearBaseIntoWork(config)
        bringBaseOnline(DB_ALIAS)
        Send_mail('BCP_FAILED ' + SERVER_NAME, mail_msg.getMsg(),config)
        raise SystemExit
    CreateAndClearOldArchive(mail_msg, config)
    clearFolder(bcp_path, 0)
    dateDiff = datetime.datetime.now() - time_start
    logger.info('DONE in {}'.format(dateDiff))
    mail_msg.addMsg('DONE in {}'.format(dateDiff))
    Send_mail('success_bcp ' + SERVER_NAME, mail_msg.getMsg(),config)
else:
    logger.warning('args not found -> STOP')
    raise SystemExit
##def Start():
##    print('Program Started')
##    input_check()
##Start()
