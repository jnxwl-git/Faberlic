import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import configparser
import logging

class mailMessage(object):
    def __init__(self, msgText):
        self.msgText = msgText
    def addMsg(self,text):
        self.msgText = self.msgText.__add__('\n'+text)
    def getMsg(self):
        return self.msgText

#mail_log = log.getLogger('Mailer')
def Send_mail(subject,message,config):
#get settings for mail_sender
    SENDER = config['MAIL']['SENDER']
    SENDER_PASSWORD = config['MAIL']['SENDER_PASSWORD']
    RECIEVERS = config['MAIL']['RECIEVERS']
    HOST = config['MAIL']['HOST']
    PORT = config['MAIL']['PORT']
    logger = logging.getLogger('Mailer')
    mail_server = smtplib.SMTP(host=HOST, port = PORT)
    mail_server.starttls()
    logger.info('Attempt to connect to server {}:{}'.format(HOST,PORT))
    try:
        mail_server.login(SENDER,SENDER_PASSWORD)
        logger.info('connected to server {}:{}'.format(HOST,PORT))
    except Exception as e:
        logger.warning('fail while login to mail server {}'.format(str(e)))
        raise Exception(str(e))
    try:
        msg=MIMEMultipart()
        msg['From'] = SENDER
        msg['To'] = RECIEVERS
        msg['Subject'] =subject
        msg.attach(MIMEText(message))
        mail_server.send_message(msg)
        logger.info('Mail sended to {}'.format(RECIEVERS))
    except Exception as e:
        logger.warning('fail while send message {}'.format(str(e)))
        raise Exception(str(e))   