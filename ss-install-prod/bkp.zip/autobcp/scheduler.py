from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.combining import OrTrigger
from apscheduler.triggers.cron import CronTrigger
import logging

#logging.getLogger('apscheduler.executors.default').setLevel(logging.WARNING)
#logging.getLogger('apscheduler.scheduler').setLevel(logging.DEBUG)
logger = logging.getLogger('apscheduler.scheduler')
task=BackgroundScheduler()
# trigger = OrTrigger([
#         CronTrigger(hour = '00', minute = '*')
#     ])    
trigger = CronTrigger(hour = '14', minute='40')
def createTask(func):
    try:
        task.add_job(func,trigger)  
        task.start()
        #logger.info('scheduler started')
    except Exception as e:
        logger.warning(str(e))
def getNextRunTime():
    for job in task.get_jobs():
        next_run=job.next_run_time.strftime('%d.%m.%y %H:%M:%S')
        job_name=job.name
    return (f'job "{job.name}", next run time {next_run}') 

def runJob():
    for job in task.get_jobs():
        job.func()
        return job.name
#scheduler.add_job(ppp,trigger='cron', trigger)  