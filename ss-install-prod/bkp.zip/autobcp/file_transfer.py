
import configparser
from datetime import datetime
from log import logging
import os,shutil,time
import zipfile


logger = logging.getLogger('file_transfer')
# CLEAR_DB_NAME = config['BASE']['CLEAR_BASE_NAME']
# bcp_path = config['BASE']['bcp_path']
dt = datetime.now().strftime('%d_%m_%H_%M') 

#mail_msg передается из MAIN в качестве параметра вызова функции  делает запись в лог и в сообщение для почты 
def setLogAndMsg(mail_msg,text):
    logger.info (text)
    mail_msg.addMsg(text)
def getCurrentTime():
    return datetime.now().strftime('%d.%m %H:%M:%S')

#создает лог для сервисного коннекта/ нужен реворк для файлтрансфера

def clearFolder(path,days):
    for f in os.listdir(path):
        if os.path.isfile(path+f):
            createDay=os.stat(os.path.join(path,f)).st_mtime
            delta = datetime.now() - datetime.fromtimestamp(createDay)
            if delta.days >= int(days):
                os.remove(os.path.join(path,f))
                logger.info('deleted file {}'.format(os.path.join(path,f)))


#Создает папки bcp_path и ancident_path из INI файла, копирует в них боевую БД
def makeDir(config):
    bcp_path = config['BASE']['bcp_path']
    ancident_path = config['BASE']['ancident_path']
    archive_path = config['BASE']['archive_path']
    logger.info ('Creting folders {} , {} , {}'.format(bcp_path,ancident_path,archive_path))
    try:
        os.mkdir(bcp_path)
    except Exception as e:
        logger.info('[makeDir]'+str(e))
    try:
        os.mkdir(ancident_path) 
    except Exception as e:
        logger.info('[makeDir]'+str(e))
    try:
        os.mkdir(archive_path)
    except Exception as e:
        logger.info('[makeDir]'+str(e))

def copyDBintoAncidentFolder(mail_msg,config):
    ancident_path = config['BASE']['ancident_path']
    DB_PATH = config['BASE']['DATABASE_PATH']
    DB_FILE = config['BASE']['DATABASE_FILE']
    ancident_sorage_days = config['RULES']['ancident_sorage_days']
    dt = datetime.now().strftime('%d_%m_%H_%M')  
    logger.info('copy {}{} to {}{}_{}'.format(DB_PATH,DB_FILE,ancident_path,dt,DB_FILE))
    #DELETE OLD DB in ancident path
    clearFolder(ancident_path,ancident_sorage_days) 
    #COPY DB FILE for ancident
    try:
        shutil.copy('{}{}'.format(DB_PATH,DB_FILE),'{}{}_{}'.format(ancident_path,dt,DB_FILE))
    except Exception as e:
        logger.warning('error while copy DB {}'.format(str(e)))
        raise Exception(str(e))
    mail_msg.addMsg('ancident base: {}{}_{}'.format(ancident_path,dt,DB_FILE))   

def renameClearBaseIntoWork(config):
    configBase = config['BASE']
    DB_PATH = configBase['DATABASE_PATH']
    DB_FILE = configBase['DATABASE_FILE']
    CLEAR_DB_NAME = configBase['CLEAR_BASE_NAME']
    logger.info('rename {}{}  into '.format(DB_PATH,CLEAR_DB_NAME) + '{}{}'.format(DB_PATH,DB_FILE))
    try:
        os.rename(r'{}{}'.format(DB_PATH,CLEAR_DB_NAME),r'{}{}'.format(DB_PATH,DB_FILE))
        os.chmod(r'{}{}'.format(DB_PATH,DB_FILE), 0o777)
    except Exception as e:
        logger.warning('[renameClearBaseIntoWork]'+str(e))

def renameBaseForClear(config):
    configBase = config['BASE']
    DB_PATH = configBase['DATABASE_PATH']
    DB_FILE = configBase['DATABASE_FILE']
    CLEAR_DB_NAME = configBase['CLEAR_BASE_NAME']
    logger.info('rename {}{}  into '.format(DB_PATH,DB_FILE) + '{}{}'.format(DB_PATH,CLEAR_DB_NAME))
    try:
        os.rename(r'{}{}'.format(DB_PATH,DB_FILE),r'{}{}'.format(DB_PATH,CLEAR_DB_NAME))
    except:
        logger.warning('file {}{} not found'.format(DB_PATH,DB_FILE))

def copyDBintoClearFolder(config):
    configBase= config['BASE']
    bcp_path = configBase['bcp_path']
    DB_PATH = configBase['DATABASE_PATH']
    CLEAR_DB_NAME = configBase['CLEAR_BASE_NAME']
    logger.info('copy {}{} to {}{}'.format(DB_PATH,CLEAR_DB_NAME,bcp_path,CLEAR_DB_NAME))
    try:
        shutil.copy('{}{}'.format(DB_PATH,CLEAR_DB_NAME),'{}{}'.format(bcp_path,CLEAR_DB_NAME))
    except Exception as e:
        logger.warning('error while copy DB {}'.format(str(e)))
        raise Exception(str(e))
    #DB_PATH/CLEAR_DB_NAME -> bcp_path/CLEAR_DB_NAME
def copyDBintoWorkFolder(config):
    configBase= config['BASE']
    bcp_path = configBase['bcp_path']
    DB_PATH = configBase['DATABASE_PATH']
    CLEAR_DB_NAME = configBase['CLEAR_BASE_NAME']
    DATABASE_FILE = configBase['DATABASE_FILE']    
    logger.info('copy {}{}_rest.fdb to {}{}'.format(bcp_path,CLEAR_DB_NAME[:-4],DB_PATH,CLEAR_DB_NAME))
    try:
        shutil.copy('{}{}_rest.fdb'.format(bcp_path,CLEAR_DB_NAME[:-4]),'{}{}'.format(DB_PATH,CLEAR_DB_NAME))
    except Exception as e:
        logger.warning('error while copy DB {}'.format(str(e)))
        raise Exception(str(e))
def CreateAndClearOldArchive(mail_msg,config):
    dt = datetime.now().strftime('%d_%m_%H_%M') 
    configBase= config['BASE']
    bcp_path = configBase['bcp_path']
    archive_path = configBase['archive_path']
    DB_ALIAS = configBase['DATABASE_ALIAS']
    CLEAR_BASE_NAME = configBase['CLEAR_BASE_NAME']
    archive_storage_days= config['RULES']['archive_storage_days']
    clearFolder(archive_path,archive_storage_days)
    currArch = zipfile.ZipFile('{}{}_{}.zip'.format(archive_path,DB_ALIAS,dt),'w',zipfile.ZIP_DEFLATED,True,6)
    currArch.write(os.path.join(bcp_path,'backup.log'),'backup.log')
    currArch.write(os.path.join(bcp_path,'restore.log'),'restore.log')
    currArch.write(os.path.join(bcp_path,'{}.fbk'.format(CLEAR_BASE_NAME[:-4])),'{}.fbk'.format(CLEAR_BASE_NAME[:-4]))
    currArch.close()
    setLogAndMsg(mail_msg,'Created archive: {}{}_{}.zip'.format(archive_path,DB_ALIAS,dt))
