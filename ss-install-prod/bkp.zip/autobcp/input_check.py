import scheduler
from log import logging

logger = logging.getLogger('input_check')
def input_check():
    while True:
        command = input()
        logger.info(f'Get console command "{command}"')
        if command == 'run_now':
            job_name=scheduler.runJob()
            logger.info(f'initiated job "{job_name}" from console is completed')
            print(f'## initiated job "{job_name}" from console is completed')
        if command == 'next_run':
            print (scheduler.getNextRunTime())