
# from fdb import services,connect
import fdb
from fdb import services
from req import sendGetRequest
import configparser
from datetime import datetime
from log import logging
import os,shutil,time


logger = logging.getLogger('fb')
#возвращает массив с информацией по транзакции 
def getTransactionInfo(tranID):
    arr=[]
    con = connectToLocalDB(DB_ALIAS)
    tr = con.trans()
    transactionInfoSQL = ("""SELECT tr.MON$TIMESTAMP, 
                                    r.mon$record_seq_reads as "Non-indexed Reads", 
                                    r.mon$record_idx_reads as "Indexed Reads", 
                                    r.mon$record_inserts as "Records Inserted", 
                                    r.mon$record_updates as "Records Updated", 
                                    r.mon$record_deletes as "Records Deleted" 
                            FROM mon$transactions tr 
                            left join mon$record_stats r on (tr.mon$stat_id = r.mon$stat_id) 
                            where tr.mon$transaction_id =""")
    tr.begin()
    trcur = tr.cursor()
    trcur.execute('{}{}'.format(transactionInfoSQL,tranID))
    data = trcur.fetchone()
    for idx,field in enumerate(trcur.description):
        if idx == 0:
            dateDiff= datetime.now() - data[idx]
            arr.append('{}:{}'.format('Time elapsed',dateDiff))
        else:
            arr.append('{}:{}'.format(field[0],data[idx]))
    tr.close()
    return arr
##mail_msg передается из MAIN в качестве параметра вызова функции делает запись в лог и в сообщение для почты 
def setLogAndMsg(mail_msg,text):
    logger.info (text)
    mail_msg.addMsg(text)
def getCurrentTime():
    return datetime.now().strftime('%d.%m %H:%M:%S')

#создает лог для сервисного коннекта
def createServiceDBLog(con,bcp_path,filename):
    try:
        f= open('{}{}.log'.format(bcp_path,filename),'w+') 
        logger.info('created log file {}{}.log'.format(bcp_path,filename))
        for x in con.readlines():
            f.write(x+'\n')
        f.close()
    except Exception as e:
        logger.error('error while creating DBLog {}'.format(str(e)))
        raise Exception(str(e))

def connectToLocalAsService():
    con = services.connect(
        host='localhost', 
        user='sysdba', 
        password='masterkey'
    )
    return con
def connectToLocalDB(DB):
    con = fdb.connect(
        host='localhost',
        database=DB,
        user ='SYSDBA',
        password = 'masterkey',
        charset = 'UTF-8'
    )
    return con

#выполняет заднный SQL, пишет информацию о транзакции
def executeSQL(sql):
    userCon = connectToLocalDB(DB_ALIAS)
    cursor=userCon.cursor()    
    try:
        cursor.execute(sql)
        mainTrun = userCon.main_transaction
        mainTrunID = mainTrun.transaction_id 
        arr = getTransactionInfo(mainTrunID)
        userCon.commit()
        for item in arr:
            print(item)
    except Exception as e:
        raise Exception(str(e))

def shutdownBase(DB_ALIAS):
    serviceCon = connectToLocalAsService()
    try:
        serviceCon.shutdown(DB_ALIAS,services.SHUT_FULL,services.SHUT_FORCE,0)
        logger.info('DB:{} is SHUTDOWNED'.format(DB_ALIAS))
    except:
        logger.info('DB:{} is down already'.format(DB_ALIAS))

def bringBaseOnline(DB_ALIAS):
    try:
        serviceCon = connectToLocalAsService()
        serviceCon.bring_online(DB_ALIAS)
        logger.info('DB:{} is bringed online'.format(DB_ALIAS))
    except:
        logger.info('DB:{} is alredy online'.format(DB_ALIAS))
def startBackupRestore(mail_msg,config,clear):
    configBase = config['BASE']
    DB_PATH = configBase['DATABASE_PATH']
    DB_FILE = configBase['DATABASE_FILE']
    DB_ALIAS = configBase['DATABASE_ALIAS']
    CLEAR_DB_NAME = configBase['CLEAR_BASE_NAME']
    bcp_path = configBase['bcp_path']
    dt = datetime.now().strftime('%d_%m_%H_%M') 
    if clear:
        configEndpoint = config['CLEAR_ENDPOINT']
        url = configEndpoint['url']
        timeout = configEndpoint['timeout_sec']
        setLogAndMsg(mail_msg, 'call '+url+' ' + getCurrentTime())
        res=sendGetRequest(url,timeout)
        setLogAndMsg(mail_msg, 'resp: ' + res + ' ' + getCurrentTime())
    # #_____________________________________________________
    con = connectToLocalAsService()
    setLogAndMsg(mail_msg,'bcp started '+getCurrentTime())
    try:
        con.backup('{}{}'.format(bcp_path,CLEAR_DB_NAME), '{}{}.fbk'.format(bcp_path,CLEAR_DB_NAME[:-4]) , collect_garbage=False)
    except Exception as e:
        logger.warning('failed while BACKUP')
        raise Exception (str(e))
    createServiceDBLog(con,bcp_path,'backup')
    setLogAndMsg(mail_msg,'bcp ended '+getCurrentTime())
    #_____________________________________________________
    setLogAndMsg(mail_msg,'restore started '+getCurrentTime())
    try:
        con.restore('{}{}.fbk'.format(bcp_path,CLEAR_DB_NAME[:-4]), '{}{}_rest.fdb'.format(bcp_path,CLEAR_DB_NAME[:-4]), replace=1)
    except Exception as e:
        logger.warning('failed while RESTORE')
        raise Exception (str(e))
    createServiceDBLog(con,bcp_path,'restore')
    setLogAndMsg(mail_msg,'restore ended '+getCurrentTime())
# restore_report = con.readlines()
# print (restore_report)